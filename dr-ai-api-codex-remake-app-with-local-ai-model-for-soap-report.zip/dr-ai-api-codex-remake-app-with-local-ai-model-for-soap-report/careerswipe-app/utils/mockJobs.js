const jobs = [
  {
    title: 'Frontend Developer',
    location: 'New York, NY',
    salary: '$80k-$100k',
    remote: true,
    tag: 'Urgent',
    description: 'Seeking frontend developer with React and Tailwind experience.',
    logo: ''
  },
  {
    title: 'Backend Engineer',
    location: 'San Francisco, CA',
    salary: '$110k-$130k',
    remote: false,
    tag: 'Internship',
    description: 'Looking for Node.js engineer familiar with databases and APIs.',
    logo: ''
  }
];
export default jobs;
