const stopwords = ['the', 'a', 'an', 'and', 'or', 'for', 'to', 'of', 'in', 'on'];

function keywords(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .split(/\s+/)
    .filter((w) => w && !stopwords.includes(w));
}

export default function matchEngine(resume, description) {
  const resumeWords = new Set(keywords(resume));
  const jobWords = new Set(keywords(description));
  const common = [...jobWords].filter((w) => resumeWords.has(w));
  const missing = [...jobWords].filter((w) => !resumeWords.has(w));
  const percent = jobWords.size ? Math.round((common.length / jobWords.size) * 100) : 0;
  return { percent, common, missing };
}
