import Link from 'next/link';

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <h1 className="text-3xl font-bold text-primary mb-4">CareerSwipe</h1>
      <p className="mb-6 text-center max-w-md">
        Swipe through jobs, auto-apply with your resume and track your career applications.
      </p>
      <Link href="/swipe" className="bg-primary text-white px-4 py-2 rounded-full">Get Started</Link>
    </div>
  );
}
