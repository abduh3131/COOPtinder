import { useState, useEffect } from 'react';
import ResumeUpload from '../components/ResumeUpload';

export default function Profile() {
  const [profile, setProfile] = useState({ name: '', email: '', phone: '', linkedin: '', github: '', portfolio: '' });

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('profile') || '{}');
    setProfile({ ...profile, ...data });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
    localStorage.setItem('profile', JSON.stringify({ ...profile, [name]: value }));
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl mb-4">Profile</h1>
      <label className="block mb-2">Name
        <input name="name" value={profile.name} onChange={handleChange} className="border p-2 w-full" />
      </label>
      <label className="block mb-2">Email
        <input name="email" value={profile.email} onChange={handleChange} className="border p-2 w-full" />
      </label>
      <label className="block mb-2">Phone
        <input name="phone" value={profile.phone} onChange={handleChange} className="border p-2 w-full" />
      </label>
      <label className="block mb-2">LinkedIn
        <input name="linkedin" value={profile.linkedin} onChange={handleChange} className="border p-2 w-full" />
      </label>
      <label className="block mb-2">GitHub
        <input name="github" value={profile.github} onChange={handleChange} className="border p-2 w-full" />
      </label>
      <label className="block mb-2">Portfolio
        <input name="portfolio" value={profile.portfolio} onChange={handleChange} className="border p-2 w-full" />
      </label>
      <ResumeUpload />
    </div>
  );
}
