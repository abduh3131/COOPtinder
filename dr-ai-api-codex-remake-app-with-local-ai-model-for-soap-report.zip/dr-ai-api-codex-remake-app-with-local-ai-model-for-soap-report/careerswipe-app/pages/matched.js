import { useEffect, useState } from 'react';
import JobCard from '../components/JobCard';

export default function Matched() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('matches') || '[]');
    setJobs(data);
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-2xl mb-4">Matched Jobs</h1>
      {jobs.length > 0 ? (
        jobs.map((job, idx) => <JobCard key={idx} job={job} />)
      ) : (
        <p>No matches yet.</p>
      )}
    </div>
  );
}
