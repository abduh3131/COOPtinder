import { useState } from 'react';
import JobCard from '../components/JobCard';
import SwipeButtons from '../components/SwipeButtons';
import jobs from '../utils/mockJobs';

export default function SwipePage() {
  const [index, setIndex] = useState(0);
  const job = jobs[index];

  const handleApply = () => {
    setIndex((i) => i + 1);
  };

  const handleSkip = () => {
    setIndex((i) => i + 1);
  };

  return (
    <div className="p-4 flex flex-col items-center">
      {job ? (
        <>
          <JobCard job={job} />
          <SwipeButtons onApply={handleApply} onSkip={handleSkip} />
        </>
      ) : (
        <p>No more jobs</p>
      )}
    </div>
  );
}
