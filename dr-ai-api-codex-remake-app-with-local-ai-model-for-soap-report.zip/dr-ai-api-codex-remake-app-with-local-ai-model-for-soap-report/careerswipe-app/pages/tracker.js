import { useEffect, useState } from 'react';

const STATUS_COLORS = {
  Offer: 'bg-primary',
  Interview: 'bg-yellow-500',
  Rejected: 'bg-red-500',
  Pending: 'bg-gray-300'
};

export default function Tracker() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('applications') || '[]');
    setJobs(data);
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-2xl mb-4">Application Tracker</h1>
      <table className="min-w-full text-left border">
        <thead className="bg-accent text-white">
          <tr>
            <th className="p-2">Job</th>
            <th className="p-2">Date</th>
            <th className="p-2">Status</th>
          </tr>
        </thead>
        <tbody>
          {jobs.map((j, idx) => (
            <tr key={idx} className="border-t">
              <td className="p-2">{j.title}</td>
              <td className="p-2">{j.date}</td>
              <td className="p-2">
                <span className={`text-white px-2 py-1 rounded ${STATUS_COLORS[j.status]}`}>{j.status}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
