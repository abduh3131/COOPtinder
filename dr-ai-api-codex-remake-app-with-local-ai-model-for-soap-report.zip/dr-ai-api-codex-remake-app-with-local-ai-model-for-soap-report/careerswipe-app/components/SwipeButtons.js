export default function SwipeButtons({ onApply, onSkip }) {
  return (
    <div className="flex justify-between w-80 mb-4">
      <button
        className="bg-red-500 text-white rounded-full w-16 h-16 text-2xl"
        onClick={onSkip}
      >
        ❌
      </button>
      <button
        className="bg-primary text-white rounded-full w-16 h-16 text-2xl"
        onClick={onApply}
      >
        ✔️
      </button>
    </div>
  );
}
