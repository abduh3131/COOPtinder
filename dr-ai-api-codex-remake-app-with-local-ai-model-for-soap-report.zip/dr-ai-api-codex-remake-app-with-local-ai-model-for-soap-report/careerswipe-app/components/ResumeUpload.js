import { useState } from 'react';

export default function ResumeUpload() {
  const [fileName, setFileName] = useState('');

  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      localStorage.setItem('resume', reader.result);
    };
    reader.readAsText(file);
  };

  return (
    <div className="mt-4">
      <label className="block mb-1">Upload Resume</label>
      <input type="file" accept=".pdf,.txt" onChange={handleFile} />
      {fileName && <p className="text-sm mt-1">{fileName} uploaded</p>}
    </div>
  );
}
