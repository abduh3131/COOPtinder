import { useEffect, useState } from 'react';
import matchEngine from '../utils/matchEngine';

export default function MatchScore({ description }) {
  const [score, setScore] = useState(null);
  const [overlap, setOverlap] = useState([]);
  const [missing, setMissing] = useState([]);

  useEffect(() => {
    const resume = localStorage.getItem('resume') || '';
    const { percent, common, missing: miss } = matchEngine(resume, description);
    setScore(percent);
    setOverlap(common);
    setMissing(miss);
  }, [description]);

  return (
    <div className="mt-2 text-sm">
      {score !== null && (
        <>
          <p>Match: {score}%</p>
          <div className="flex justify-between text-xs mt-1">
            <div className="w-1/2 pr-1">
              <h4>Resume</h4>
              <ul className="list-disc list-inside">
                {overlap.map((o) => <li key={o}>{o}</li>)}
              </ul>
            </div>
            <div className="w-1/2 pl-1">
              <h4>Missing</h4>
              <ul className="list-disc list-inside text-red-500">
                {missing.map((m) => <li key={m}>{m}</li>)}
              </ul>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
