import Link from 'next/link';

export default function NavBar() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-2">
      <Link href="/swipe" className="text-center">
        <div>🏠</div>
        <span className="text-xs">Home</span>
      </Link>
      <Link href="/matched" className="text-center">
        <div>❤️</div>
        <span className="text-xs">Matches</span>
      </Link>
      <Link href="/tracker" className="text-center">
        <div>📋</div>
        <span className="text-xs">Tracker</span>
      </Link>
      <Link href="/profile" className="text-center">
        <div>👤</div>
        <span className="text-xs">Profile</span>
      </Link>
    </nav>
  );
}
