import MatchScore from './MatchScore';

export default function JobCard({ job }) {
  return (
    <div className="bg-white rounded-2xl shadow p-4 w-80 mb-4">
      <div className="flex items-center mb-2">
        {job.logo && <img src={job.logo} alt="logo" className="h-10 w-10 mr-2" />}
        <h2 className="text-xl font-semibold">{job.title}</h2>
      </div>
      <p className="text-sm mb-1">{job.location} &middot; {job.salary}</p>
      <p className="text-sm mb-2">{job.remote ? 'Remote' : 'On-site'}</p>
      {job.tag && <span className="bg-accent text-white px-2 py-1 rounded-full text-xs">{job.tag}</span>}
      <MatchScore description={job.description} />
    </div>
  );
}
