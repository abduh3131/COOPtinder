/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./pages/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        primary: '#009A44',
        accent: '#00B14F',
        text: '#1C1C1C'
      }
    }
  },
  plugins: []
};
